/*
** hw4_lib.c:
**
** The source file implementing library functions.
**
** Author: Yakup Genc. (c) 2018
**
** Revision: 2018.03.27.08.19
** 
*/

#include "hw4_lib.h"
#include <math.h>

double integral(double f(double x), double xs, double xe, double delta){ // fonksiyonun altında kalan alanı olan integralinin sürekli olarak ne kadar küçük bir değer 
	double area=0,i=0;													 // verilirse gerçek değere o kadar yaklaşacağı şekilde her seferinde o dikdörtgen ile çarpılıp	
	for(i=xs; i<xe; i=i+delta){											//eklenerek bulunduğu fonksiyon(riemann teoremi)
		area += (f(i)*delta);
	}
	return area;
}
double integral2(double f(double x, double y), double xs, double xe, double ys, double ye, double delta){ //integral bulmayla aynı mantıklı y ekseni de hesaba katıldığından
	double volume=0,i=0,j=0;																			  //bir delta ile daha carpılarak hacmin bulunması
	for(i=xs; i<xe; i=i+delta){
		for (j=ys;  j<ye; j=j+delta){		
			volume +=  (f(i,j)*delta*delta);

		}
	}
	return volume;
}
int derivatives(double f(double a), double x, double eps, double * d1, double * d2){ //1. ve 2. türevin bilinen forülleri aracılığıyla bulunması
		
		*d1 = (f(x+eps)-f(x-eps))/ (2*eps);
		*d2 = (f(x+eps)-(2*f(x))+f(x-eps))/(eps*eps);
		return (0);

		if(eps == 0)
			return (-1);

}
int compare_derivatives(double f(double a), double d1(double b), double d2(double b), double x, double eps, double * e1, double * e2){ //numerik şekilde bulunan türev ile
	double derivative1, derivative2;																									//fonksiyon halinde hesabı verilen 
	derivatives(f,x,eps,&derivative1,&derivative2);																						//türevlerin sonuçlarının hesaplanması
	*e1 = fabs(d1(x) - derivative1);
	*e2 = fabs(d2(x) - derivative2);
	return 0;
}

