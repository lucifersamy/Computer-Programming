/*
** hw4_io.c:
**
** The source file implementing input and output functions.
**
** Author: Yakup Genc. (c) 2018
**
** Revision: 2018.03.27.08.19
** 
*/

#include "hw4_io.h"
#include <stdio.h>

int read_polynomial3(double * a0, double * a1, double * a2, double * a3){
     while(*a3 == 0.00){
        printf("enter a3 that is not 0:");
        scanf("%lf",a3);
     }
     printf("enter a2:");
     scanf("%lf",a2);
     printf("enter a1:");
     scanf("%lf",a1);                  
     printf("enter a0:");
     scanf("%lf",a0);
     
     return (0);
}
int read_polynomial4(double * a0, double * a1, double * a2, double * a3, double * a4){
     while(*a4 == 0.00){
        printf("enter a4 that is not 0:");
        scanf("%lf",a4);
     }
     printf("enter a3:");
     scanf("%lf",a3);                   
     printf("enter a2:");
     scanf("%lf",a2);    
     printf("enter a1:");
     scanf("%lf",a1);         
     printf("enter a0:");
     scanf("%lf",a0);
     
     return (0);        
}
void write_polynomial3(double a0, double a1, double a2, double a3){ //noktadan sonraki gereksiz 0ları atan, kat sayı eğer 1 ya da-1 ise katsayıyı
    if(a3 == 1.00)													//yazmayan ve kullanıcıdan alınan katsayıları uygun polinom formatında 3 ve 4 için
    	printf("x^3");												//yazdıran fonksiyonlar
    else if(a3 == -1.00)											
	    printf("-x^3");
    else if(a3 == 0){}
    else
       printf("%gx^3",a3);

    if(a2 == 1.00)
       printf("x^2");
    else if(a2 == -1.00)
       printf("-x^3");
    else if(a2 == 0){}
    else
       printf("%+gx^2",a2);

    if(a1 == 1.00)
       printf("x^2");
    else if(a1 == -1.00)
       printf("-x");
    else if(a1 == 0){}
    else
       printf("%+gx",a1);

    if(a0 == 0){}
    else
       printf("%+g",a0);
     printf("\n");
}
void write_polynomial4(double a0, double a1, double a2, double a3, double a4){
	if(a4 == 1.00)				
	   printf("x^4");
	else if(a4 == -1.00)
	   printf("-x^4");
	else if(a4 == 0){}
	else
	   printf("%gx^4",a4);

	if(a3 == 1.00)
	   printf("x^3");
	else if(a3 == -1.00)
	   printf("-x^3");
	else if(a3 == 0){}
	else
	   printf("%+gx^3",a3);

	if(a2 == 1.00)
	   printf("x^2");
	else if(a2 == -1.00)
	   printf("-x^3");
	else if(a2 == 0){}
	else
	   printf("%+gx^2",a2);

	if(a1 == 1.00)
	   printf("x^2");
	else if(a1 == -1.00)
	   printf("-x");
	else if(a1 == 0){}
	else
	   printf("%+gx",a1);

	if(a0 == 0){}
	else 
	   printf("%+g",a0);
     printf("\n");
}

